function setup() {
  createCanvas(400, 400);
}
var scene = "menu";
var play = "play";



function draw() {

if (scene === "menu"){
fill(145, 125, 125);
ellipse(200,200,2000,2000);
fill(255, 0, 0); 
rect(10,228,179,118);
fill(0, 140, 255);
rect(207,232,179,118);
//blue play button
fill(0, 140, 255);
rect(110,117,179,100);
textSize(35);
text("snake by voltagenesis",38,56,1943,1958);
//text "play"
fill(170, 255, 0);
textSize(50);
text("play",158,140,5260,100);}
 
      
};


//if statements
if (scene === "play"){
    background(255, 0, 0);
    fill(255, 0, 0);

} 
 var draw = function() {
    if (mouseIsPressed && mouseX >290 && mouseX <113 && mouseY >121 && mouseY <217  ) { 
       
            
       
        fill(0, 0, 0);
        ellipse(200,200,200,200);
        }    
    
};

    var draw = function() {
    
    if (mouseIsPressed) {
        strokeWeight(5);
        point(mouseX, mouseY);
        fill(0, 0, 0);
        textSize(12);
        text(mouseX + " " +"," + " "+ mouseY, mouseX-26,mouseY-10);        
    
       
}
  
       
};

